import { base64, hex } from '../../../src/encodings/index.js';
import { Binary } from '../binary.js';
import { type SymmetricCipher } from '../ciphers/symmetric-cipher-base.js';
import { type KeyAccess, type KeyAccessObject } from './key-access.js';
import { type Policy } from './policy.js';
import {
  type CryptoService,
  type DecryptResult,
  type EncryptResult,
  type SymmetricKey,
} from '../crypto/declarations.js';
import {
  ROOT_INTEGRITY_ALGORITHM,
  SEGMENT_INTEGRITY_ALGORITHM,
  type RootIntegrityAlgorithm,
  type SegmentIntegrityAlgorithm,
} from '../tdf.js';
import { ConfigurationError } from '../../../src/errors.js';

export type KeyInfo = {
  readonly unwrappedKey: SymmetricKey;
  readonly unwrappedKeyIvBinary: Binary;
};

export type Segment = {
  readonly hash: string;
  // If not present, segmentSizeDefault must be defined and used.
  readonly segmentSize?: number;
  // If not present, encryptedSegmentSizeDefault must be defined and used.??
  readonly encryptedSegmentSize?: number;
};

export type SplitType = 'split';

export type EncryptionInformation = {
  readonly type: SplitType;
  readonly keyAccess: KeyAccessObject[];
  readonly integrityInformation: {
    readonly rootSignature: {
      /**
       * Algorithm declared by the file. Untrusted until validated on read;
       * only `HS256` is accepted (see `asRootIntegrityAlgorithm`). Typed as a
       * plain string because a hostile manifest may say anything.
       */
      alg: RootIntegrityAlgorithm | string;
      sig: string;
    };
    /** Untrusted until validated on read; `GMAC` and `HS256` are accepted. */
    segmentHashAlg?: SegmentIntegrityAlgorithm | string;
    segments: Segment[];
    segmentSizeDefault?: number;
    encryptedSegmentSizeDefault?: number;
  };
  readonly method: {
    readonly algorithm: string;
    isStreamable: boolean;
    readonly iv: string;
  };
  policy: string;
};

export class SplitKey {
  readonly cryptoService: CryptoService;
  keyAccess: KeyAccess[];

  constructor(public readonly cipher: SymmetricCipher) {
    this.cryptoService = cipher.cryptoService;
    this.keyAccess = [];
  }

  async generateKey(): Promise<KeyInfo> {
    const unwrappedKey = await this.cipher.generateKey();
    const unwrappedKeyIvBinary = await this.generateIvBinary();
    return { unwrappedKey, unwrappedKeyIvBinary };
  }

  async encrypt(
    contentBinary: Binary,
    key: SymmetricKey,
    ivBinaryOptional?: Binary
  ): Promise<EncryptResult> {
    const ivBinary = ivBinaryOptional || (await this.generateIvBinary());
    return this.cipher.encrypt(contentBinary, key, ivBinary);
  }

  async decrypt(content: ArrayBuffer | Uint8Array, key: SymmetricKey): Promise<DecryptResult> {
    return this.cipher.decrypt(content, key);
  }

  async getKeyAccessObjects(policy: Policy, keyInfo: KeyInfo): Promise<KeyAccessObject[]> {
    const splitIds = [...new Set(this.keyAccess.map(({ sid }) => sid))].sort((a = '', b = '') =>
      a.localeCompare(b)
    );
    const unwrappedKeySplits = await this.cryptoService.splitSymmetricKey(
      keyInfo.unwrappedKey,
      splitIds.length
    );
    const splitsByName = Object.fromEntries(
      splitIds.map((sid, index) => [sid, unwrappedKeySplits[index]])
    );

    const keyAccessObjects = [];
    for (const item of this.keyAccess) {
      // use the key split to encrypt metadata for each key access object
      const unwrappedKeySplit = splitsByName[item.sid || ''];

      const metadata = item.metadata || '';
      const metadataStr = (
        typeof metadata === 'object'
          ? JSON.stringify(metadata)
          : typeof metadata === 'string'
            ? metadata
            : () => {
                throw new ConfigurationError(
                  "KAO generation failure: metadata isn't a string or object"
                );
              }
      ) as string;

      const metadataBinary = Binary.fromArrayBuffer(new TextEncoder().encode(metadataStr));

      const encryptedMetadataResult = await this.encrypt(
        metadataBinary,
        unwrappedKeySplit,
        keyInfo.unwrappedKeyIvBinary
      );

      const encryptedMetadataOb = {
        ciphertext: base64.encode(encryptedMetadataResult.payload.asString()),
        iv: base64.encode(keyInfo.unwrappedKeyIvBinary.asString()),
      };

      const encryptedMetadataStr = JSON.stringify(encryptedMetadataOb);
      const keyAccessObject = await item.write(policy, unwrappedKeySplit, encryptedMetadataStr);
      keyAccessObjects.push(keyAccessObject);
    }

    return keyAccessObjects;
  }

  async generateIvBinary(): Promise<Binary> {
    const iv = await this.cipher.generateInitializationVector();
    return Binary.fromString(hex.decode(iv));
  }

  async write(policy: Policy, keyInfo: KeyInfo): Promise<EncryptionInformation> {
    const algorithm = this.cipher?.name;
    if (!algorithm) {
      // Hard coded as part of the cipher object. This should not be reachable.
      throw new ConfigurationError('uninitialized cipher type');
    }
    const keyAccessObjects = await this.getKeyAccessObjects(policy, keyInfo);

    // For now we're only concerned with a single (first) key access object
    const policyForManifest = base64.encode(JSON.stringify(policy));

    return {
      type: 'split',
      keyAccess: keyAccessObjects,
      method: {
        algorithm,
        isStreamable: false,
        iv: base64.encode(keyInfo.unwrappedKeyIvBinary.asString()),
      },
      integrityInformation: {
        rootSignature: {
          // Placeholders; `writeStream` overwrites both once the payload has
          // been segmented and the aggregate hash is known.
          alg: ROOT_INTEGRITY_ALGORITHM,
          sig: '',
        },
        segmentHashAlg: SEGMENT_INTEGRITY_ALGORITHM,
        segments: [],
      },
      policy: policyForManifest,
    };
  }
}
